
If you use the code, please cite the paper "Tao Lei, Xiaohong Jia, Yanning Zhang, Shigang Liu, Hongying Meng and Asoke K. Nandi, Superpixel-based Fast Fuzzy C-Means Clustering for Color Image Segmentation, IEEE Transactions on Fuzzy Systems,DOI:10.1109/TFUZZ.2018.288901820182019, 2018"

